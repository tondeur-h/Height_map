#include <QtGui> 
#include "DiamondSquareApp.h"
 
// if we include <QtGui> there is no need to include every class used: <QString>, <QFileDialog>,...
 
DiamondSquareApp::DiamondSquareApp(QWidget *parent)
{
  setupUi(this); // this sets up GUI
  QObject::connect(Ui::MyDialog::GenerateButton, SIGNAL(clicked()), this, SLOT(generateSlot()));
  QObject::connect(Ui::MyDialog::exitButton, SIGNAL(clicked()), this, SLOT(exitSlot()));
}


void DiamondSquareApp::generateSlot()
{
  unsigned int unPower;
  float fVariability, fDistance;
  
  unPower = static_cast<unsigned int>(powerLineEdit->text().toInt());
  fVariability = variabilityLineEdit->text().toFloat();
  fDistance = distanceLineEdit->text().toFloat();

  diamondSquareWidget2->generate(unPower, fVariability, fDistance);
  
}

void DiamondSquareApp::exitSlot()
{
  exit(0);
}
