#ifndef MYQTAPP_H
#define MYQTAPP_H
 
#include "ui_DiamondSquareDialog.h"
 
 
class DiamondSquareApp : public QDialog, private Ui::MyDialog
{
    Q_OBJECT
 
public:
    DiamondSquareApp(QWidget *parent = 0);

 private slots:
 virtual void generateSlot();
  virtual void exitSlot();


};

 
#endif
