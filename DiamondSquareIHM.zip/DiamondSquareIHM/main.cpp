#include <QApplication>
 
#include "DiamondSquareApp.h"
 
int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    DiamondSquareApp *dialog = new DiamondSquareApp();
 
    dialog->show();
    return app.exec();
}
