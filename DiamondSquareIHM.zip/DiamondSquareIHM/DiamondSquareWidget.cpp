#include "DiamondSquareWidget.h"
#include <iostream>

DiamondSquareWidget::DiamondSquareWidget(QWidget *parent,  const char *name) :
  QGLWidget(parent)
{ 
  // DiamondSquare
  pEngine = new CDiamondSquare(6, 0.5f, 2.0f);
  pEngine->Generate();
  
  m_fTX = m_fTY = m_fTZ = 0.0f;
  m_fRX = m_fRY = m_fRZ = 0.0f;
}

/*!
  Release allocated resources
*/
DiamondSquareWidget::~DiamondSquareWidget()
{
}


/*!
  Paint the box. The actual openGL commands for drawing the box are
  performed here.
*/

void DiamondSquareWidget::paintGL()
{
  glClearColor( 0.4, 0.4, 1.0, 0.0 );
  glClearDepth( 1.0 );
  glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
  glMatrixMode( GL_MODELVIEW );
  glLoadIdentity();
  
  gluLookAt(0.0+m_fTX+m_fRX, 24.0+m_fTY+m_fRY, 20.0+m_fTZ+m_fRZ,
	       0.0+m_fTX, 24.0+m_fTY, 0.0+m_fTZ,
	       0.0, 1.0, 0.0 );
  
  glMatrixMode( GL_PROJECTION );
  glLoadIdentity();
  glFrustum( -1.0, 1.0, -1.0, 1.0, 1.0, 100.0 );

  if (pEngine != NULL)
	{
	  glColor3f(0.0f, 1.0f, 0.0f);
	  pEngine->Draw();
	}
}


/*!
  Set up the OpenGL rendering state, and define display list
*/

void DiamondSquareWidget::initializeGL()
{
  // qglClearColor( black ); 		// Let OpenGL clear to black

}

/*!
  Set up the OpenGL view port, matrix mode, etc.
*/

void DiamondSquareWidget::resizeGL( int w, int h )
{
    glViewport( 0, 0, (GLint)w, (GLint)h );
}

void DiamondSquareWidget::changeMode()
{
  pEngine->ChangeMode();
  updateGL();
}

void DiamondSquareWidget::rotateMinusXSlot()
{
    m_fRX -=2.0f;
    updateGL();
}

void DiamondSquareWidget::rotateMinusYSlot()
{
    m_fRY -=2.0f;
    updateGL();
}

void DiamondSquareWidget::rotateMinusZSlot()
{
    m_fRZ -=2.0f;
    updateGL();
}

void DiamondSquareWidget::rotatePlusXSlot()
{
    m_fRX +=2.0f;
    updateGL();
}

void DiamondSquareWidget::rotatePlusYSlot()
{
    m_fRY +=2.0f;
    updateGL();
}

void DiamondSquareWidget::rotatePlusZSlot()
{
    m_fRZ +=2.0f;
    updateGL();
}

void DiamondSquareWidget::translateMinusXSlot()
{
    m_fTX -=2.0f;
    updateGL();
}

void DiamondSquareWidget::translateMinusYSlot()
{
    m_fTY -=2.0f;
    updateGL();
}

void DiamondSquareWidget::translateMinusZSlot()
{
    m_fTZ -=2.0f;
    updateGL();
}

void DiamondSquareWidget::translatePlusXSlot()
{
    m_fTX +=2.0f;
    updateGL();
}

void DiamondSquareWidget::translatePlusYSlot()
{
    m_fTY +=2.0f;
    updateGL();
}

void DiamondSquareWidget::translatePlusZSlot()
{
    m_fTZ +=2.0f;
    updateGL();
}

void DiamondSquareWidget::generate(unsigned int unPower, float fVariability,
								   float fSize)
{
  std::cout << unPower << ", " << fVariability << ", " << fSize << std::endl;
  delete pEngine;
  pEngine = new CDiamondSquare(unPower, fVariability, fSize);
  pEngine->Generate();
  updateGL();
}
