#pragma once

// QT
#include <QtOpenGL/qgl.h>

// Divers
#include <GL/gl.h>
#include <iostream>
#include "DiamondSquare.h"

class DiamondSquareWidget : public QGLWidget
{
  Q_OBJECT
  
public:
  DiamondSquareWidget(QWidget *parent=0, const char *name=0);
  ~DiamondSquareWidget();

protected :
  virtual void initializeGL();
  virtual void resizeGL( int width, int height );
  virtual void paintGL();

protected slots :
  
  // Rotation
  virtual void rotateMinusXSlot();
  virtual void rotateMinusYSlot();
  virtual void rotateMinusZSlot();
  virtual void rotatePlusXSlot();
  virtual void rotatePlusYSlot();
  virtual void rotatePlusZSlot();
  
  // Translation
  virtual void translateMinusXSlot();
  virtual void translateMinusYSlot();
  virtual void translateMinusZSlot();
  virtual void translatePlusXSlot();
  virtual void translatePlusYSlot();
  virtual void translatePlusZSlot();
  
  // Mode
  virtual void changeMode();
  
private:
  CDiamondSquare *pEngine;
  
public:
    float m_fTX, m_fTY, m_fTZ;
  float m_fRX, m_fRY, m_fRZ;

public:
   void generate(unsigned int unPower, float fVariability, float fSize);
};
